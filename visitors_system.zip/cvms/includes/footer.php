<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>VMS 2021 All rights reserved.</p>
                                </div>
                            </div>
                        </div>